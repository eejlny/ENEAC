#ifndef MM_H
#define MM_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <assert.h>



#define N             1024  // N should be power of 2, and larger than 8
#define M             1024  // M should be power of 2, and larger than 8
#define P             1024   // P should be power of 2, and larger than 8

#define rows  	      1024


#define BLOCK 256
#define BLOCK_I 1

float step;

float *array_a; 
float *array_b; 
float *array_c;
float *c_golden;


void writeoutput(float *, int, int, char *);
void readinput(float *, int, int, char *);

int compute_matrix_mult(float *,float*, float*);

void usage(int, char **);
void run(int, char **);



#endif
